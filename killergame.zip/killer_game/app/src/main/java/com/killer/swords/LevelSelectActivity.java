package com.killer.swords;
import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
public class LevelSelectActivity extends Activity {
    int selectedWorld=0;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_level_select);
        buildTabs();showWorld(0);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
    }
    void buildTabs(){
        LinearLayout tabs=findViewById(R.id.worldTabs);tabs.removeAllViews();
        int max=GameData.getMaxUnlockedLevel(this);
        for(int wi=0;wi<GameData.WORLDS.length;wi++){
            GameData.WorldDef w=GameData.WORLDS[wi];boolean locked=w.unlockAtLevel>max;final int idx=wi;
            TextView tab=new TextView(this);tab.setText(locked?"🔒":w.name);tab.setTextColor(locked?0xFF555555:0xFFFFFFFF);
            tab.setTextSize(11);tab.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);tab.setGravity(android.view.Gravity.CENTER);tab.setPadding(dp(8),dp(10),dp(8),dp(10));
            tab.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1));
            tab.setBackgroundColor(wi==selectedWorld?(w.accentColor&0x00FFFFFF|0x88000000):0x22000000);
            if(!locked)tab.setOnClickListener(v->{selectedWorld=idx;showWorld(idx);buildTabs();});
            tabs.addView(tab);
        }
    }
    void showWorld(int wi){
        GameData.WorldDef world=GameData.WORLDS[wi];GameData.LevelDef[]levels=GameData.LEVELS[wi];int max=GameData.getMaxUnlockedLevel(this);
        TextView tn=findViewById(R.id.tvWorldName),ts=findViewById(R.id.tvWorldSub);
        if(tn!=null){tn.setText(world.name);tn.setTextColor(world.accentColor);}if(ts!=null)ts.setText(world.subtitle);
        LinearLayout grid=findViewById(R.id.levelGrid);grid.removeAllViews();
        LinearLayout row=null;
        for(int li=0;li<levels.length;li++){
            GameData.LevelDef lvl=levels[li];int gIdx=lvl.globalIndex();boolean locked=gIdx>max;int stars=GameData.getLevelStars(this,gIdx);final GameData.LevelDef fl=lvl;
            if(li%3==0){row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(android.view.Gravity.CENTER);LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rlp.setMargins(0,0,0,dp(12));row.setLayoutParams(rlp);grid.addView(row);}
            FrameLayout card=makeCard(lvl,locked,stars,world);if(!locked)card.setOnClickListener(v->openPreview(fl,world));row.addView(card);
        }
    }
    FrameLayout makeCard(GameData.LevelDef lvl,boolean locked,int stars,GameData.WorldDef world){
        FrameLayout card=new FrameLayout(this);
        LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(dp(100),dp(110));clp.setMargins(dp(6),0,dp(6),0);card.setLayoutParams(clp);
        View bg=new View(this);bg.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        bg.setBackgroundColor(locked?0xFF1A1A1A:(lvl.hasBoss?0xFF2A0011:0xFF1A1A2A));card.addView(bg);
        View strip=new View(this);FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(4));slp.gravity=android.view.Gravity.TOP;strip.setLayoutParams(slp);
        strip.setBackgroundColor(locked?0xFF333333:(lvl.hasBoss?0xFFFF0044:world.accentColor));card.addView(strip);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(android.view.Gravity.CENTER);content.setPadding(dp(6),dp(8),dp(6),dp(8));content.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));card.addView(content);
        TextView tvN=new TextView(this);tvN.setText(locked?"🔒":(lvl.hasBoss?"👑":String.valueOf(lvl.levelIdx+1)));tvN.setTextSize(locked?22:26);tvN.setTextColor(locked?0xFF555555:(lvl.hasBoss?0xFFFFD700:0xFFFFFFFF));tvN.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);tvN.setGravity(android.view.Gravity.CENTER);tvN.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));content.addView(tvN);
        TextView tvNm=new TextView(this);tvNm.setText(lvl.name);tvNm.setTextSize(9);tvNm.setTextColor(locked?0xFF444444:0xFF888888);tvNm.setGravity(android.view.Gravity.CENTER);tvNm.setTypeface(Typeface.MONOSPACE);content.addView(tvNm);
        if(!locked){TextView tvS=new TextView(this);tvS.setText((stars>=1?"★":"☆")+(stars>=2?"★":"☆")+(stars>=3?"★":"☆"));tvS.setTextSize(16);tvS.setTextColor(0xFFFFD700);tvS.setGravity(android.view.Gravity.CENTER);content.addView(tvS);}
        return card;
    }
    void openPreview(GameData.LevelDef lvl,GameData.WorldDef world){
        android.app.AlertDialog.Builder builder=new android.app.AlertDialog.Builder(this);
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(20),dp(20),dp(20),dp(16));v.setBackgroundColor(world.bgDark);
        TextView tt=new TextView(this);tt.setText(lvl.hasBoss?"👑 "+lvl.name:lvl.name);tt.setTextSize(20);tt.setTextColor(world.accentColor);tt.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);tt.setGravity(android.view.Gravity.CENTER);v.addView(tt);
        TextView tw=new TextView(this);tw.setText(world.name+" — "+world.subtitle);tw.setTextSize(12);tw.setTextColor(0xFF888888);tw.setTypeface(Typeface.MONOSPACE);tw.setGravity(android.view.Gravity.CENTER);tw.setPadding(0,dp(4),0,dp(12));v.addView(tw);
        GameData.SwordDef showcase=GameData.getSword(lvl.showcaseSword);
        if(!GameData.isSwordUnlocked(this,lvl.showcaseSword)){TextView tn=new TextView(this);tn.setText("🆕 Открывается: "+showcase.name);tn.setTextSize(13);tn.setTextColor(0xFFFFD700);tn.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);tn.setGravity(android.view.Gravity.CENTER);tn.setPadding(0,0,0,dp(8));v.addView(tn);}
        addRow(v,"Волн:",String.valueOf(lvl.waves));addRow(v,"Враги:",lvl.hasBoss?"✚ БОСС":"Охрана");addRow(v,"Подсказка:",lvl.hint);
        GameData.SwordDef s1=GameData.getSword(GameData.getEquippedSword(this,1)),s2=GameData.getSword(GameData.getEquippedSword(this,2));
        addRow(v,"Мечи:",s1.name+" + "+s2.name);addRow(v,"Рывок:",s1.dashType.name);addRow(v,"Умение:",s1.skillType.name);
        int stars=GameData.getLevelStars(this,lvl.globalIndex());
        if(stars>0){TextView ts=new TextView(this);ts.setText("Лучший: "+(stars>=1?"★":"☆")+(stars>=2?"★":"☆")+(stars>=3?"★":"☆"));ts.setTextSize(18);ts.setTextColor(0xFFFFD700);ts.setGravity(android.view.Gravity.CENTER);ts.setPadding(0,dp(8),0,0);v.addView(ts);}
        builder.setView(v);
        builder.setPositiveButton("▶  ИГРАТЬ",(d,w2)->{Intent i=new Intent(this,GameActivity.class);i.putExtra("world",lvl.worldIdx);i.putExtra("level",lvl.levelIdx);startActivityForResult(i,1);});
        builder.setNegativeButton("Назад",null);
        android.app.AlertDialog dlg=builder.create();if(dlg.getWindow()!=null)dlg.getWindow().setBackgroundDrawableResource(android.R.color.black);dlg.show();
        if(dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE)!=null)dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(world.accentColor);
    }
    void addRow(LinearLayout p2,String label,String value){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);rlp.setMargins(0,dp(3),0,dp(3));row.setLayoutParams(rlp);
        TextView tl=new TextView(this);tl.setText(label);tl.setTextSize(11);tl.setTextColor(0xFF666666);tl.setTypeface(Typeface.MONOSPACE);tl.setLayoutParams(new LinearLayout.LayoutParams(dp(80),ViewGroup.LayoutParams.WRAP_CONTENT));row.addView(tl);
        TextView tv=new TextView(this);tv.setText(value);tv.setTextSize(11);tv.setTextColor(0xFFCCCCCC);tv.setTypeface(Typeface.MONOSPACE);row.addView(tv);p2.addView(row);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==1){showWorld(selectedWorld);buildTabs();}}
    int dp(float d){return(int)(d*getResources().getDisplayMetrics().density);}
}
