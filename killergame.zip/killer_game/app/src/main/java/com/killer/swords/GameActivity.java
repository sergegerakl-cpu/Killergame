package com.killer.swords;

import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.view.*;
import android.widget.*;

public class GameActivity extends Activity implements GameView.CB {

    GameView gv;
    Handler ui = new Handler(Looper.getMainLooper());
    int worldIdx, levelIdx;

    View     hpFill, staFill;
    TextView tvWave, tvScore, tvSkillCd, tvDashCd, tvAnnounce;
    View     joyZone, joyKnob, joyBase;
    int      joyId = -1;
    float    joyR;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        worldIdx = getIntent().getIntExtra("world", 0);
        levelIdx  = getIntent().getIntExtra("level", 0);
        GameData.LevelDef lvl   = GameData.LEVELS[worldIdx][levelIdx];
        GameData.WorldDef world = GameData.WORLDS[worldIdx];

        setContentView(R.layout.activity_game);
        gv = new GameView(this, lvl, world.theme);
        gv.cb = this;
        ((FrameLayout)findViewById(R.id.gameContainer)).addView(gv, 0);

        bind(); setupJoy(); setupBtns();
    }

    void bind() {
        hpFill     = findViewById(R.id.hpFill);
        staFill    = findViewById(R.id.staFill);
        tvWave     = findViewById(R.id.tvWave);
        tvScore    = findViewById(R.id.tvScore);
        tvSkillCd  = findViewById(R.id.tvSkillCd);
        tvDashCd   = findViewById(R.id.tvDashCd);
        tvAnnounce = findViewById(R.id.tvAnnounce);
        joyZone    = findViewById(R.id.joyZone);
        joyKnob    = findViewById(R.id.joyKnob);
        joyBase    = findViewById(R.id.joyBase);
        joyR       = dp(50);

        // sword info
        if (gv.getSw1() != null) {
            setTv(R.id.tvS1Name, gv.getSw1().def.name);
            setTv(R.id.tvS1Abil, gv.getSw1().def.skillType.name);
            setTv(R.id.tvDash,   gv.getSw1().def.dashType.name);
        }
        if (gv.getSw2() != null) setTv(R.id.tvS2Name, gv.getSw2().def.name);
    }

    void setTv(int id, String t) { TextView tv=findViewById(id); if(tv!=null) tv.setText(t); }

    void setupJoy() {
        joyZone.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (joyId == -1) { joyId = ev.getPointerId(ev.getActionIndex()); moveKnob(ev.getX(ev.getActionIndex()), ev.getY(ev.getActionIndex()), v); }
                    break;
                case MotionEvent.ACTION_MOVE:
                    for (int i=0;i<ev.getPointerCount();i++) if(ev.getPointerId(i)==joyId) moveKnob(ev.getX(i),ev.getY(i),v);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (ev.getPointerId(ev.getActionIndex())==joyId) { joyId=-1; gv.setJoy(0,0); centerKnob(); }
                    break;
            }
            return true;
        });
    }

    void moveKnob(float tx, float ty, View zone) {
        float cx=zone.getWidth()/2f, cy=zone.getHeight()/2f;
        float dx=tx-cx, dy=ty-cy, d=(float)Math.sqrt(dx*dx+dy*dy);
        float nx=d>0?dx/d:0, ny=d>0?dy/d:0, cl=Math.min(d,joyR);
        gv.setJoy(nx, ny);
        if (joyKnob!=null) { joyKnob.setX(cx+nx*cl-joyKnob.getWidth()/2f); joyKnob.setY(cy+ny*cl-joyKnob.getHeight()/2f); }
    }

    void centerKnob() {
        if (joyBase==null||joyKnob==null) return;
        joyKnob.post(() -> { joyKnob.setX(joyBase.getWidth()/2f-joyKnob.getWidth()/2f); joyKnob.setY(joyBase.getHeight()/2f-joyKnob.getHeight()/2f); });
    }

    void setupBtns() {
        touch(R.id.btnAttack, () -> gv.tapAttack());
        touch(R.id.btnSkill,  () -> gv.tapSkill());
        touch(R.id.btnDash,   () -> gv.tapDash());
        findViewById(R.id.btnPause).setOnClickListener(v -> showPause());
    }

    void touch(int id, Runnable r) {
        View v = findViewById(id);
        if (v != null) v.setOnTouchListener((vv,ev) -> { if(ev.getActionMasked()==MotionEvent.ACTION_DOWN) r.run(); return true; });
    }

    void showPause() {
        gv.pause();
        new android.app.AlertDialog.Builder(this)
            .setTitle("⏸  ПАУЗА")
            .setPositiveButton("Продолжить", (d,w) -> gv.resume())
            .setNegativeButton("Выйти", (d,w) -> { setResult(RESULT_OK); finish(); })
            .setCancelable(false).show();
    }

    // ── CB ──────────────────────────────────────────────────────────────
    @Override
    public void onHud(int hp, int maxHp, int sta, int staMax, int wave, int wTotal, int score, int skillCd, int dashCd) {
        ui.post(() -> {
            setBar(hpFill,  R.id.hpBar,  (float)hp/maxHp);
            setBar(staFill, R.id.staBar, (float)sta/staMax);
            if (tvWave  != null) tvWave.setText("ВОЛНА "+wave+"/"+wTotal);
            if (tvScore != null) tvScore.setText(String.valueOf(score));
            if (tvSkillCd != null) tvSkillCd.setText(skillCd>0 ? String.valueOf(skillCd/60+1) : "✓");
            if (tvDashCd  != null) tvDashCd.setText(dashCd >0 ? String.valueOf(dashCd /60+1) : "✓");
        });
    }

    @Override
    public void onDead(int score, int gold) {
        ui.post(() -> {
            GameData.addScore(this, score);
            new android.app.AlertDialog.Builder(this)
                .setTitle("☠  УБИТ")
                .setMessage("Счёт: "+score+"\nЗолото: "+gold)
                .setPositiveButton("Заново", (d,w) -> { finish(); startActivity(getIntent()); })
                .setNegativeButton("Меню",   (d,w) -> { setResult(RESULT_OK); finish(); })
                .setCancelable(false).show();
        });
    }

    @Override
    public void onWin(int stars, int score, int gold) {
        ui.post(() -> {
            GameData.LevelDef lvl = GameData.LEVELS[worldIdx][levelIdx];
            GameData.saveLevelStars(this, lvl.globalIndex(), stars);
            GameData.unlockLevel(this, lvl.globalIndex() + 1);
            GameData.addGold(this, gold);
            GameData.addScore(this, score);
            GameData.unlockSword(this, lvl.showcaseSword);

            String ss = (stars>=1?"★":"☆")+(stars>=2?"★":"☆")+(stars>=3?"★":"☆");
            GameData.SwordDef sw = GameData.getSword(lvl.showcaseSword);
            String msg = ss+"\n\nСчёт: "+score+"\nЗолото: +"+gold+"\n\n🆕 Открыт: "+sw.name;

            new android.app.AlertDialog.Builder(this)
                .setTitle("✓  УРОВЕНЬ ПРОЙДЕН!")
                .setMessage(msg)
                .setPositiveButton("Следующий", (d,w) -> { setResult(RESULT_OK); nextLevel(); })
                .setNegativeButton("Меню",       (d,w) -> { setResult(RESULT_OK); finish(); })
                .setCancelable(false).show();
        });
    }

    @Override
    public void onWaveDone(int wave) {
        ui.post(() -> {
            if (tvAnnounce != null) {
                tvAnnounce.setText("✓ ВОЛНА "+wave+" ПРОЙДЕНА!");
                tvAnnounce.setVisibility(View.VISIBLE);
                ui.postDelayed(() -> tvAnnounce.setVisibility(View.GONE), 2000);
            }
        });
    }

    void nextLevel() {
        Intent i = new Intent(this, GameActivity.class);
        if (levelIdx+1 < GameData.LEVELS[worldIdx].length) {
            i.putExtra("world", worldIdx); i.putExtra("level", levelIdx+1);
        } else if (worldIdx+1 < GameData.WORLDS.length) {
            i.putExtra("world", worldIdx+1); i.putExtra("level", 0);
        } else { finish(); return; }
        finish(); startActivity(i);
    }

    void setBar(View fill, int barId, float frac) {
        View bar = findViewById(barId);
        if (bar==null||fill==null) return;
        bar.post(() -> { ViewGroup.LayoutParams lp=fill.getLayoutParams(); lp.width=(int)(bar.getWidth()*Math.max(0,Math.min(1,frac))); fill.setLayoutParams(lp); });
    }

    float dp(float d) { return d * getResources().getDisplayMetrics().density; }

    @Override public void onBackPressed() { showPause(); }
}
