package com.killer.swords;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    // ── Constants ─────────────────────────────────────────────────────────
    static final int WORLD = 2800, TILE = 72;
    static final int COLS  = WORLD / TILE, ROWS = WORLD / TILE;

    // ── Inner types ───────────────────────────────────────────────────────
    static class Sword {
        GameData.SwordDef def;
        int level;
        float restAngle;          // 0 or PI
        float currentAngle;
        boolean spinning;
        float spinProgress;       // 0→1 = one full revolution
        float spinSpeed = 0.055f;
        boolean doubleRev;        // skill = 2 revolutions
        int hitCooldown;          // prevents same enemy hit twice per frame

        Sword(GameData.SwordDef d, float rest, int lv) {
            def = d; level = lv; restAngle = rest; currentAngle = rest;
        }
        int damage() { return def.baseDmg * level; }
    }

    static class Player {
        float x = WORLD / 2f, y = WORLD / 2f, r = 20;
        int   hp, maxHp;
        float stamina = 100, maxStamina = 100;
        float spd;
        float facing = 0;
        Sword sw1, sw2;
        // dash
        boolean dashing; float dashVx, dashVy; int dashFrames;
        // cooldowns
        int invincible, dashCd, skillCd;
    }

    static class Enemy {
        float x, y, r, spd, facing, patrolAngle, phase;
        int   hp, maxHp, dmg, color;
        int   shootCd, meleeCd, stunned, burnTimer, frozenTimer, pullTimer, patrolTimer, dodgeCd;
        boolean alive = true, alerted, isBoss;
        Renderer.EnemyKind kind;
    }

    static class Bullet {
        float x, y, vx, vy, r = 8;
        int dmg, color, life = 130;
    }

    static class Particle {
        float x, y, vx, vy, r, alpha = 1;
        int color, life, maxLife;
        boolean isNum; String text;
    }

    static class Pickup { float x, y, bob; boolean isHp; int life = 450; }

    static class DashTrail { float x, y, r, alpha; int color; }

    // ── Fields ────────────────────────────────────────────────────────────
    private Thread  thread;
    private volatile boolean running;
    private final Context ctx;

    enum State { PLAYING, PAUSED, WAVE_CLEAR, DEAD, WIN }
    State state = State.PLAYING;

    // Level config
    GameData.LevelDef levelDef;
    String worldTheme;
    int worldIdx;

    // Wave
    int wave, waveTotal, waveKilled, waveSpawned;
    float spawnCd, announceTimer, clearTimer;
    int levelFrame, maxLevelFrames;

    // World grid: true = wall
    final boolean[][] grid = new boolean[ROWS][COLS];

    final List<Enemy>     enemies   = new ArrayList<>();
    final List<Bullet>    bullets   = new ArrayList<>();
    final List<Particle>  particles = new ArrayList<>();
    final List<Pickup>    pickups   = new ArrayList<>();
    final List<DashTrail> trails    = new ArrayList<>();

    final Player player = new Player();

    // Camera + shake
    float camX, camY, shakeX, shakeY, shakeAmt;

    // Input
    float joyX, joyY;
    volatile boolean flagAttack, flagSkill, flagDash;

    // Session stats
    int sessionScore, sessionGold;

    // Paints
    final Paint p  = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint ps = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
    { ps.setStyle(Paint.Style.STROKE); pt.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)); pt.setAntiAlias(true); }

    final Random rng = new Random();

    // Callback
    interface CB {
        void onHud(int hp, int maxHp, int sta, int staMax, int wave, int wTotal, int score, int skillCd, int dashCd);
        void onDead(int score, int gold);
        void onWin(int stars, int score, int gold);
        void onWaveDone(int wave);
    }
    CB cb;

    // ── Constructor ───────────────────────────────────────────────────────
    public GameView(Context ctx, GameData.LevelDef def, String theme) {
        super(ctx);
        this.ctx = ctx;
        levelDef  = def;
        worldTheme = theme;
        worldIdx   = def.worldIdx;
        getHolder().addCallback(this);
        setFocusable(true);

        player.maxHp  = GameData.getPlayerMaxHp(ctx);
        player.hp     = player.maxHp;
        player.spd    = GameData.getPlayerSpeed(ctx);
        GameData.SwordDef d1 = GameData.getSword(GameData.getEquippedSword(ctx, 1));
        GameData.SwordDef d2 = GameData.getSword(GameData.getEquippedSword(ctx, 2));
        player.sw1 = new Sword(d1, 0,            GameData.getSwordLevel(ctx, d1.id));
        player.sw2 = new Sword(d2, (float)Math.PI, GameData.getSwordLevel(ctx, d2.id));

        maxLevelFrames = (60 + def.waves * 30) * 60;
        wave = 1;
        generateMap();
        startWave();
    }

    // ── Map ───────────────────────────────────────────────────────────────
    void generateMap() {
        for (boolean[] row : grid) Arrays.fill(row, false);
        for (int c = 0; c < COLS; c++) { grid[0][c] = true; grid[ROWS-1][c] = true; }
        for (int r = 0; r < ROWS; r++) { grid[r][0] = true; grid[r][COLS-1] = true; }
        int rooms = 8 + worldIdx * 2 + wave;
        for (int i = 0; i < rooms; i++) {
            int rw = 2 + rng.nextInt(4), rh = 2 + rng.nextInt(4);
            int rc = 3 + rng.nextInt(COLS - rw - 6), rr = 3 + rng.nextInt(ROWS - rh - 6);
            if (dist(rc * TILE + rw * TILE / 2f, rr * TILE + rh * TILE / 2f, WORLD / 2f, WORLD / 2f) < 280) continue;
            for (int dr = rr; dr <= rr + rh; dr++)
                for (int dc = rc; dc <= rc + rw; dc++)
                    if (dc < COLS && dr < ROWS) grid[dr][dc] = true;
            int side = rng.nextInt(4);
            try {
                if (side == 0 && rw > 0) grid[rr][rc + rng.nextInt(rw)] = false;
                else if (side == 1 && rw > 0) grid[rr + rh][rc + rng.nextInt(rw)] = false;
                else if (side == 2 && rh > 0) grid[rr + rng.nextInt(rh)][rc] = false;
                else if (rh > 0) grid[rr + rng.nextInt(rh)][rc + rw] = false;
            } catch (Exception ignored) {}
        }
        for (int i = 0; i < 14 + worldIdx * 2; i++) {
            int c = 3 + rng.nextInt(COLS - 6), r = 3 + rng.nextInt(ROWS - 6);
            if (dist(c * TILE + TILE / 2f, r * TILE + TILE / 2f, WORLD / 2f, WORLD / 2f) > 220)
                grid[r][c] = true;
        }
    }

    boolean isWall(float x, float y, float r) {
        float[] xs = {x-r+2, x+r-2, x-r+2, x+r-2, x};
        float[] ys = {y-r+2, y-r+2, y+r-2, y+r-2, y};
        for (int i = 0; i < 5; i++) {
            int c = (int)(xs[i]/TILE), row = (int)(ys[i]/TILE);
            if (c < 0 || c >= COLS || row < 0 || row >= ROWS || grid[row][c]) return true;
        }
        return false;
    }

    // ── Wave ──────────────────────────────────────────────────────────────
    void startWave() {
        enemies.clear(); bullets.clear(); pickups.clear();
        waveKilled = 0; waveSpawned = 0; spawnCd = 65; announceTimer = 180;
        waveTotal = (4 + wave * 3) * levelDef.enemyMult;
    }

    void spawnEnemy() {
        if (waveSpawned >= waveTotal) return;
        waveSpawned++;
        float sx, sy; int tries = 0;
        do {
            double a = rng.nextDouble() * Math.PI * 2;
            float d2 = 320 + rng.nextFloat() * 600;
            sx = Math.max(TILE*2, Math.min(WORLD-TILE*2, player.x + (float)Math.cos(a)*d2));
            sy = Math.max(TILE*2, Math.min(WORLD-TILE*2, player.y + (float)Math.sin(a)*d2));
            tries++;
        } while (tries < 30 && isWall(sx, sy, 20));

        boolean boss = levelDef.hasBoss && waveSpawned == waveTotal && wave == levelDef.waves;
        Enemy e = new Enemy();
        e.x = sx; e.y = sy; e.isBoss = boss;
        e.patrolAngle = rng.nextFloat() * (float)(Math.PI * 2);
        e.phase = rng.nextFloat() * (float)(Math.PI * 2);
        e.facing = (float)Math.atan2(player.y - sy, player.x - sx);

        if (boss) {
            e.kind = worldIdx == 4 ? Renderer.EnemyKind.BOSS_FINAL : Renderer.EnemyKind.BOSS_MAIN;
            e.r = 36; e.maxHp = 280 + worldIdx*60 + wave*30;
            e.spd = 1.2f; e.dmg = 22; e.color = 0xFFFF0044;
            e.shootCd = 45; e.meleeCd = 50;
        } else {
            Renderer.EnemyKind[] pool = enemyPool();
            e.kind = pool[rng.nextInt(pool.length)];
            configEnemy(e);
        }
        e.hp = e.maxHp;
        enemies.add(e);
    }

    Renderer.EnemyKind[] enemyPool() {
        switch (worldIdx) {
            case 0: return new Renderer.EnemyKind[]{Renderer.EnemyKind.GUARD, Renderer.EnemyKind.GUARD, Renderer.EnemyKind.DOG, Renderer.EnemyKind.SNIPER};
            case 1: return new Renderer.EnemyKind[]{Renderer.EnemyKind.GUARD, Renderer.EnemyKind.SNIPER, Renderer.EnemyKind.DRONE, Renderer.EnemyKind.HEAVY};
            case 2: return new Renderer.EnemyKind[]{Renderer.EnemyKind.ROBOT, Renderer.EnemyKind.DRONE, Renderer.EnemyKind.HEAVY, Renderer.EnemyKind.SNIPER};
            case 3: return new Renderer.EnemyKind[]{Renderer.EnemyKind.MAGE, Renderer.EnemyKind.DOG, Renderer.EnemyKind.GUARD, Renderer.EnemyKind.ROBOT};
            default:return new Renderer.EnemyKind[]{Renderer.EnemyKind.ROBOT, Renderer.EnemyKind.MAGE, Renderer.EnemyKind.HEAVY, Renderer.EnemyKind.DRONE};
        }
    }

    void configEnemy(Enemy e) {
        float diff = 1 + worldIdx * 0.4f + wave * 0.15f;
        switch (e.kind) {
            case GUARD:  e.r=17; e.maxHp=(int)(30*diff); e.spd=1.4f+worldIdx*.1f; e.dmg=(int)(8*diff);  e.color=0xFFCC3333; e.meleeCd=40; break;
            case SNIPER: e.r=15; e.maxHp=(int)(22*diff); e.spd=0.7f;               e.dmg=(int)(18*diff); e.color=0xFF998833; e.shootCd=85; e.dodgeCd=90; break;
            case HEAVY:  e.r=22; e.maxHp=(int)(65*diff); e.spd=1.0f+worldIdx*.08f; e.dmg=(int)(14*diff); e.color=0xFF2244AA; e.meleeCd=55; e.shootCd=110; break;
            case DRONE:  e.r=14; e.maxHp=(int)(18*diff); e.spd=2.0f+worldIdx*.1f;  e.dmg=(int)(6*diff);  e.color=0xFF445566; e.shootCd=70; break;
            case DOG:    e.r=14; e.maxHp=(int)(25*diff); e.spd=2.2f+worldIdx*.15f; e.dmg=(int)(10*diff); e.color=0xFF885533; e.meleeCd=28; break;
            case MAGE:   e.r=16; e.maxHp=(int)(28*diff); e.spd=1.1f;               e.dmg=(int)(16*diff); e.color=0xFF660088; e.shootCd=65; break;
            case ROBOT:  e.r=18; e.maxHp=(int)(55*diff); e.spd=1.3f+worldIdx*.1f;  e.dmg=(int)(12*diff); e.color=0xFF334455; e.meleeCd=50; e.shootCd=100; break;
            default:     e.r=16; e.maxHp=30; e.spd=1.4f; e.dmg=8; e.color=0xFFCC3333;
        }
    }

    // ── ATTACK: 360° spin ─────────────────────────────────────────────────
    void doAttack() {
        if (player.sw1.spinning || player.sw2.spinning) return;
        player.sw1.spinning = true;  player.sw1.spinProgress = 0; player.sw1.doubleRev = false;
        player.sw2.spinning = true;  player.sw2.spinProgress = 0; player.sw2.doubleRev = false;
        player.sw1.spinSpeed = 0.055f; player.sw2.spinSpeed = 0.055f;
    }

    void doSkill() {
        if (player.skillCd > 0 || player.stamina < 28) return;
        player.stamina -= 28; player.skillCd = 160;
        switch (player.sw1.def.skillType) {
            case SPIN_360:
                player.sw1.spinning = true; player.sw1.spinProgress = 0; player.sw1.doubleRev = true; player.sw1.spinSpeed = 0.09f;
                player.sw2.spinning = true; player.sw2.spinProgress = 0; player.sw2.doubleRev = true; player.sw2.spinSpeed = 0.09f;
                break;
            case FIRE_STORM:
                for (Enemy e : enemies) { if (!e.alive) continue; if (dist(e.x,e.y,player.x,player.y)<190){ e.burnTimer=180; hitEnemy(e,20,player.sw1); } }
                burst(player.x, player.y, 0xFFFF6600, 40); shake(10); break;
            case BLIZZARD:
                for (Enemy e : enemies) { if (!e.alive) continue; e.frozenTimer=200; burst(e.x,e.y,0xFF88CCFF,5); }
                burst(player.x, player.y, 0xFF88DDFF, 50); shake(8); break;
            case THUNDER_STRIKE:
                List<Enemy> sorted = new ArrayList<>(enemies);
                sorted.sort((a,b)->(int)(dist(a.x,a.y,player.x,player.y)-dist(b.x,b.y,player.x,player.y)));
                int hits = 0; float lx = player.x, ly = player.y;
                for (Enemy e : sorted) { if (!e.alive || hits >= 3) break; hitEnemy(e, player.sw1.damage()*3, player.sw1); lightningLine(lx,ly,e.x,e.y); lx=e.x; ly=e.y; hits++; }
                shake(10); break;
            case BLACK_HOLE:
                for (Enemy e : enemies) { if (!e.alive) continue; e.pullTimer=120; hitEnemy(e,15,player.sw1); }
                for (int i=0;i<60;i++){float a=i*(float)(Math.PI*2)/60; addParticle(player.x+100*(float)Math.cos(a),player.y+100*(float)Math.sin(a),-2*(float)Math.cos(a),-2*(float)Math.sin(a),0xFFAA44FF,40,5);}
                shake(8); break;
            case SHADOW_REALM:
                for (Enemy e : enemies) { if (!e.alive) continue; if(dist(e.x,e.y,player.x,player.y)<260){hitEnemy(e,player.sw1.damage()*4,player.sw1); e.spd*=0.4f;} }
                burst(player.x, player.y, 0xFFCC00AA, 30); shake(12); break;
            case PLASMA_BURST:
                for (int i=0;i<12;i++){float a=i*(float)(Math.PI*2/12); Bullet b=new Bullet(); b.x=player.x; b.y=player.y; b.vx=(float)Math.cos(a)*7; b.vy=(float)Math.sin(a)*7; b.dmg=player.sw1.damage()*2; b.color=0xFF00FFCC; b.life=80; bullets.add(b);}
                shake(8); break;
            case TIDAL_WAVE:
                for (Enemy e : enemies){if(!e.alive)continue;float wa=(float)Math.atan2(e.y-player.y,e.x-player.x);if(dist(e.x,e.y,player.x,player.y)<320){e.x+=(float)Math.cos(wa)*80;e.y+=(float)Math.sin(wa)*80;hitEnemy(e,player.sw1.damage()*2,player.sw1);}}
                burst(player.x, player.y, 0xFF0066FF, 50); shake(10); break;
            case QUAKE:
                shake(22);
                for (Enemy e : enemies){if(!e.alive)continue;e.stunned=180;hitEnemy(e,player.sw1.damage()*2,player.sw1);}
                for(int i=0;i<60;i++) addParticle(player.x+rng.nextFloat()*500-250,player.y+rng.nextFloat()*500-250,0,0,0xFF8B4513,20,6);
                break;
        }
    }

    void doDash() {
        if (player.dashCd > 0 || player.stamina < 18) return;
        player.stamina -= 18; player.dashCd = 65;
        float ndx = Math.abs(joyX)>0.05f ? joyX : (float)Math.cos(player.facing);
        float ndy = Math.abs(joyY)>0.05f ? joyY : (float)Math.sin(player.facing);

        switch (player.sw1.def.dashType) {
            case BLINK: {
                // instant teleport
                float bx = player.x + ndx * 130, by = player.y + ndy * 130;
                if (!isWall(bx, by, player.r)) { player.x = bx; player.y = by; }
                burst(player.x, player.y, player.sw1.def.color, 14);
                player.invincible = 20;
                return; // no slide, just teleport
            }
            case THUNDER_LEAP: {
                // stun enemies at destination
                float bx = player.x + ndx * 100, by = player.y + ndy * 100;
                for (Enemy e : enemies) { if(!e.alive) continue; if(dist(e.x,e.y,bx,by)<80){e.stunned=70;hitEnemy(e,player.sw1.damage(),player.sw1);} }
                burst(bx, by, 0xFFFFFF44, 10);
                break;
            }
            case FLAME_DASH:
                // leave fire trail — handled per-frame
                break;
            case FROST_SLIDE:
                // freeze enemies touched during dash — handled per-frame
                break;
            case SHADOW_STEP:
                player.invincible = 40; // longer invincible
                break;
        }

        player.dashing = true; player.dashFrames = 12; player.invincible = Math.max(player.invincible, 18);
        player.dashVx = ndx * 15; player.dashVy = ndy * 15;
    }

    // ── Hit logic ─────────────────────────────────────────────────────────
    void hitEnemy(Enemy e, int dmg, Sword sw) {
        if (e.stunned > 5 && !e.isBoss) return;
        if (e.frozenTimer > 0) dmg = (int)(dmg * 1.5f);
        e.hp -= dmg; e.stunned = 10;
        addNumber(e.x, e.y - e.r, dmg, sw.def.color);
        burst(e.x, e.y, sw.def.color, 5);

        switch (sw.def.id) {
            case FIRE:       e.burnTimer  = 180;  break;
            case ICE:        if(e.frozenTimer<=0){e.frozenTimer=100;e.spd*=0.35f;}  break;
            case LIGHTNING:  burst(e.x,e.y,0xFFFFFF44,8); if(rng.nextBoolean()) e.stunned=30; break;
            case VORTEX:     e.pullTimer  = 90;   break;
            case SHADOW:     e.hp -= dmg/2; burst(e.x,e.y,0xFFCC00AA,5); break;
            case PLASMA:     e.hp -= (int)(dmg*.3f); break;
            case TSUNAMI:    float pa=(float)Math.atan2(e.y-player.y,e.x-player.x); e.x+=(float)Math.cos(pa)*50; e.y+=(float)Math.sin(pa)*50; break;
            case EARTHQUAKE: e.stunned=55; shake(4); break;
        }
        if (e.hp <= 0) killEnemy(e);
    }

    void hitPlayer(int dmg) {
        if (player.invincible > 0 || player.dashing) return;
        player.hp = Math.max(0, player.hp - dmg);
        player.invincible = 40; shake(8);
        burst(player.x, player.y, 0xFFFF2222, 6);
        if (player.hp <= 0) { state = State.DEAD; if (cb != null) cb.onDead(sessionScore, sessionGold); }
        notifyHud();
    }

    void killEnemy(Enemy e) {
        if (!e.alive) return;
        e.alive = false; waveKilled++;
        int pts  = e.isBoss ? 800 : 100 + worldIdx*30 + wave*20;
        int gold = e.isBoss ? 120 : 30 + worldIdx*10;
        sessionScore += pts; sessionGold += gold;
        addNumber(e.x, e.y - e.r - 12, pts, 0xFFFFD700);
        burst2(e.x, e.y, e.color, e.isBoss ? 28 : 14);
        shake(e.isBoss ? 14 : 4);
        if (rng.nextFloat() < 0.38f) { Pickup pk = new Pickup(); pk.x=e.x; pk.y=e.y; pk.isHp=rng.nextBoolean(); pickups.add(pk); }
        notifyHud();
        checkWaveEnd();
    }

    void checkWaveEnd() {
        if (waveKilled < waveTotal) return;
        if (wave >= levelDef.waves) {
            state = State.WIN;
            int stars = GameData.calcStars(player.hp, player.maxHp, levelFrame, maxLevelFrames);
            if (cb != null) cb.onWin(stars, sessionScore, sessionGold);
        } else {
            state = State.WAVE_CLEAR; clearTimer = 110;
            if (cb != null) cb.onWaveDone(wave);
        }
    }

    // ── Update ────────────────────────────────────────────────────────────
    void update() {
        if (state == State.DEAD || state == State.WIN) return;
        if (state == State.PAUSED) return;
        if (state == State.WAVE_CLEAR) {
            if (--clearTimer <= 0) { wave++; generateMap(); player.x=WORLD/2f; player.y=WORLD/2f; particles.clear(); bullets.clear(); startWave(); state=State.PLAYING; }
            return;
        }

        levelFrame++;
        if (announceTimer > 0) announceTimer--;

        // Spawn
        if (--spawnCd <= 0 && waveSpawned < waveTotal) { spawnCd = Math.max(18, 75-wave*5-worldIdx*3); spawnEnemy(); }

        // Input flags
        if (flagAttack) { flagAttack = false; doAttack(); }
        if (flagSkill)  { flagSkill  = false; doSkill(); }
        if (flagDash)   { flagDash   = false; doDash(); }

        // ── Sword spin ──
        for (Sword sw : new Sword[]{player.sw1, player.sw2}) {
            if (!sw.spinning) { sw.currentAngle = sw.restAngle + player.facing; continue; }
            sw.spinProgress += sw.spinSpeed;
            sw.currentAngle  = sw.restAngle + player.facing + sw.spinProgress * (float)(Math.PI * 2);
            float limit = sw.doubleRev ? 2f : 1f;
            // Sword tip position
            float orbitR = 65;
            float tipX = player.x + (float)Math.cos(sw.currentAngle) * orbitR;
            float tipY = player.y + (float)Math.sin(sw.currentAngle) * orbitR;
            // Hit enemies
            for (Enemy e : enemies) {
                if (!e.alive) continue;
                if (dist(tipX, tipY, e.x, e.y) < e.r + 32) hitEnemy(e, sw.damage(), sw);
            }
            // Spin trail
            if (particles.size() < 280) addParticle(tipX, tipY, (rng.nextFloat()-.5f), (rng.nextFloat()-.5f), sw.def.color, 8, 4);
            if (sw.spinProgress >= limit) { sw.spinning = false; sw.spinProgress = 0; }
        }

        // ── Player movement ──
        if (player.dashing) {
            movePlayer(player.dashVx, player.dashVy);
            // Dash-type effects
            if (player.sw1.def.dashType == GameData.DashType.FLAME_DASH)
                addParticle(player.x, player.y, rng.nextFloat()-0.5f, rng.nextFloat()-0.5f, 0xFFFF4400, 16, 5);
            if (player.sw1.def.dashType == GameData.DashType.FROST_SLIDE) {
                for (Enemy e : enemies) { if(!e.alive)continue; if(dist(e.x,e.y,player.x,player.y)<player.r+e.r+8) e.frozenTimer=80; }
            }
            DashTrail dt = new DashTrail(); dt.x=player.x; dt.y=player.y; dt.r=player.r; dt.alpha=0.5f; dt.color=player.sw1.def.color;
            trails.add(dt); if(trails.size()>10) trails.remove(0);
            if (--player.dashFrames <= 0) player.dashing = false;
        } else {
            movePlayer(joyX * player.spd, joyY * player.spd);
            if (Math.abs(joyX) > 0.05f || Math.abs(joyY) > 0.05f) player.facing = (float)Math.atan2(joyY, joyX);
        }

        if (player.invincible > 0) player.invincible--;
        if (player.dashCd    > 0) player.dashCd--;
        if (player.skillCd   > 0) player.skillCd--;
        if (player.stamina < player.maxStamina) player.stamina = Math.min(player.maxStamina, player.stamina + 0.5f);

        // ── Enemies ──
        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy e = it.next();
            if (!e.alive) { it.remove(); continue; }
            e.phase += 0.14f;
            if (e.stunned > 0)    { e.stunned--;  continue; }
            if (e.burnTimer > 0)  { e.burnTimer--; if(e.burnTimer%22==0){e.hp-=5; addParticle(e.x,e.y,rng.nextFloat()-.5f,-1.5f,0xFFFF5500,14,4); if(e.hp<=0){killEnemy(e);continue;}} }
            if (e.frozenTimer > 0){ e.frozenTimer--; continue; }
            if (e.pullTimer > 0)  { e.pullTimer--; float pa=(float)Math.atan2(player.y-e.y,player.x-e.x); e.x+=(float)Math.cos(pa)*4; e.y+=(float)Math.sin(pa)*4; }

            float dx = player.x-e.x, dy = player.y-e.y, dd = dist(dx, dy);
            e.facing = (float)Math.atan2(dy, dx);

            if (dd < 380 || e.alerted) {
                e.alerted = true;
                // Separation
                for (Enemy o : enemies) {
                    if (o==e||!o.alive) continue;
                    float ox=e.x-o.x, oy=e.y-o.y, od=dist(ox,oy);
                    if (od < e.r+o.r+4 && od > .1f) { float push=(e.r+o.r+4-od)/od*.6f; e.x+=ox*push; e.y+=oy*push; }
                }
                // Move toward player
                if (dd > e.r + player.r + 6) {
                    float nx = e.x + (float)Math.cos(e.facing)*e.spd;
                    float ny = e.y + (float)Math.sin(e.facing)*e.spd;
                    if (!isWall(nx,e.y,e.r)) e.x=nx; else e.x+=rng.nextFloat()-.5f;
                    if (!isWall(e.x,ny,e.r)) e.y=ny; else e.y+=rng.nextFloat()-.5f;
                }
                // Sniper dodge
                if (e.kind==Renderer.EnemyKind.SNIPER && e.dodgeCd>0) e.dodgeCd--;
                if (e.kind==Renderer.EnemyKind.SNIPER && e.dodgeCd==0 && dd<200 && rng.nextInt(100)==0) {
                    float da=(float)(e.facing+Math.PI/2*(rng.nextBoolean()?1:-1));
                    float nx2=e.x+(float)Math.cos(da)*60, ny2=e.y+(float)Math.sin(da)*60;
                    if (!isWall(nx2,ny2,e.r)) { e.x=nx2; e.y=ny2; burst(e.x,e.y,e.color,3); e.dodgeCd=80; }
                }
                // Melee
                if (e.meleeCd > 0) e.meleeCd--;
                if (e.meleeCd==0 && dd<e.r+player.r+14) { hitPlayer(e.dmg); e.meleeCd=e.isBoss?44:36; }
                // Ranged
                boolean canShoot = e.isBoss || e.kind==Renderer.EnemyKind.SNIPER || e.kind==Renderer.EnemyKind.DRONE || e.kind==Renderer.EnemyKind.MAGE || e.kind==Renderer.EnemyKind.HEAVY || e.kind==Renderer.EnemyKind.ROBOT;
                if (e.shootCd > 0) e.shootCd--;
                if (e.shootCd==0 && canShoot && dd<(e.isBoss?330:280)) {
                    fireBullet(e);
                    e.shootCd = e.isBoss?40:(e.kind==Renderer.EnemyKind.SNIPER?80:90);
                }
            } else {
                // Patrol
                if (--e.patrolTimer <= 0) { e.patrolTimer=80; e.patrolAngle+=(rng.nextFloat()-.5f)*2.5f; }
                float nx=e.x+(float)Math.cos(e.patrolAngle)*e.spd*.45f;
                float ny=e.y+(float)Math.sin(e.patrolAngle)*e.spd*.45f;
                if (!isWall(nx,e.y,e.r)&&nx>TILE&&nx<WORLD-TILE) e.x=nx; else e.patrolAngle+=1f;
                if (!isWall(e.x,ny,e.r)&&ny>TILE&&ny<WORLD-TILE) e.y=ny; else e.patrolAngle+=1f;
            }
        }

        // ── Bullets ──
        Iterator<Bullet> bi = bullets.iterator();
        while (bi.hasNext()) {
            Bullet b = bi.next(); b.x+=b.vx; b.y+=b.vy; b.life--;
            if (b.life<=0||isWall(b.x,b.y,b.r)) { burst(b.x,b.y,b.color,3); bi.remove(); continue; }
            if (dist(b.x,b.y,player.x,player.y)<player.r+b.r) { hitPlayer(b.dmg); bi.remove(); }
        }

        // ── Particles ──
        Iterator<Particle> pi = particles.iterator();
        while (pi.hasNext()) {
            Particle pt = pi.next(); pt.x+=pt.vx; pt.y+=pt.vy; pt.vx*=.88f; pt.vy*=.88f; pt.life--;
            pt.alpha = (float)pt.life / pt.maxLife;
            if (pt.life<=0) pi.remove();
        }

        // ── Pickups ──
        Iterator<Pickup> pki = pickups.iterator();
        while (pki.hasNext()) {
            Pickup pk = pki.next(); pk.bob+=.1f; pk.life--;
            if (dist(pk.x,pk.y,player.x,player.y)<26) {
                if (pk.isHp) { player.hp=Math.min(player.maxHp,player.hp+30); } else sessionGold+=20;
                notifyHud(); pki.remove(); continue;
            }
            if (pk.life<=0) pki.remove();
        }

        // ── Trails fade ──
        Iterator<DashTrail> ti = trails.iterator();
        while (ti.hasNext()) { DashTrail t=ti.next(); t.alpha-=.08f; if(t.alpha<=0) ti.remove(); }

        // ── Camera ──
        float W=getWidth(), H=getHeight();
        camX = Math.max(0, Math.min(WORLD-W, player.x-W/2f));
        camY = Math.max(0, Math.min(WORLD-H, player.y-H/2f));
        if (shakeAmt>.3f) { shakeX=(rng.nextFloat()-.5f)*shakeAmt; shakeY=(rng.nextFloat()-.5f)*shakeAmt; shakeAmt*=.80f; } else { shakeX=0; shakeY=0; }
    }

    void movePlayer(float vx, float vy) {
        float nx=player.x+vx, ny=player.y+vy;
        if (!isWall(nx,player.y,player.r-2)) player.x=Math.max(TILE+player.r,Math.min(WORLD-TILE-player.r,nx));
        if (!isWall(player.x,ny,player.r-2)) player.y=Math.max(TILE+player.r,Math.min(WORLD-TILE-player.r,ny));
    }

    void fireBullet(Enemy e) {
        float sa = (float)Math.atan2(player.y-e.y, player.x-e.x);
        float spd = e.isBoss ? 5.5f : (e.kind==Renderer.EnemyKind.SNIPER ? 5f : 3.8f);
        Bullet b = new Bullet(); b.x=e.x; b.y=e.y; b.vx=(float)Math.cos(sa)*spd; b.vy=(float)Math.sin(sa)*spd; b.dmg=e.dmg; b.color=e.color; bullets.add(b);
        if (e.isBoss) {
            for (int i=-1;i<=1;i+=2) { Bullet b2=new Bullet(); b2.x=e.x; b2.y=e.y; b2.vx=(float)Math.cos(sa+i*.28f)*spd; b2.vy=(float)Math.sin(sa+i*.28f)*spd; b2.dmg=e.dmg/2; b2.color=e.color; bullets.add(b2); }
        }
    }

    // ── Render ────────────────────────────────────────────────────────────
    void render(Canvas cv) {
        int W = getWidth(), H = getHeight();
        cv.drawColor(GameData.WORLDS[worldIdx].bgDark);
        cv.save(); cv.translate(-camX + shakeX, -camY + shakeY);

        // Floor + walls (culled)
        int c0=Math.max(0,(int)(camX/TILE)-1), c1=Math.min(COLS-1,(int)((camX+W)/TILE)+1);
        int r0=Math.max(0,(int)(camY/TILE)-1), r1=Math.min(ROWS-1,(int)((camY+H)/TILE)+1);
        for (int r=r0;r<=r1;r++) for (int c=c0;c<=c1;c++) {
            if (grid[r][c]) Renderer.drawWallTile(cv,c*TILE,r*TILE,TILE,worldTheme);
            else Renderer.drawFloorTile(cv,c*TILE,r*TILE,TILE,worldTheme,(r+c)%2==0);
        }

        // Pickups
        for (Pickup pk : pickups) {
            float bob = (float)Math.sin(pk.bob)*4;
            p.setColor(pk.isHp ? 0x44FF2244 : 0x44FFD700); cv.drawCircle(pk.x,pk.y+bob,18,p);
            p.setColor(pk.isHp ? 0xFFFF2244 : 0xFFFFD700); cv.drawCircle(pk.x,pk.y+bob,10,p);
            p.setColor(pk.isHp ? 0xFFFF88AA : 0xFFFFEE88); cv.drawCircle(pk.x,pk.y+bob,5,p);
        }

        // Particles
        for (Particle pt : particles) {
            if (pt.isNum) {
                pt.setAlpha((int)(pt.alpha*255));
                p.setColor(pt.color); p.setAlpha((int)(pt.alpha*255));
                // draw text via Paint
                Paint tp=new Paint(Paint.ANTI_ALIAS_FLAG); tp.setTypeface(Typeface.MONOSPACE); tp.setTextAlign(Paint.Align.CENTER);
                tp.setTextSize(30*pt.alpha+12); tp.setColor(pt.color); tp.setAlpha((int)(pt.alpha*255));
                cv.drawText(pt.text, pt.x, pt.y, tp);
            } else {
                p.setColor(pt.color); p.setAlpha((int)(pt.alpha*200));
                cv.drawCircle(pt.x, pt.y, pt.r*pt.alpha+.5f, p); p.setAlpha(255);
            }
        }
        p.setAlpha(255);

        // Dash trails
        for (DashTrail dt : trails) { p.setColor(dt.color); p.setAlpha((int)(dt.alpha*100)); cv.drawCircle(dt.x,dt.y,dt.r,p); p.setAlpha(255); }

        // Enemies
        for (Enemy e : enemies) {
            if (!e.alive || !inView(e.x,e.y,e.r+20)) continue;
            Renderer.drawEnemy(cv,e.kind,e.x,e.y,e.r,e.facing,(float)e.hp/e.maxHp,e.isBoss,e.burnTimer,e.frozenTimer,e.phase);
        }

        // Bullets
        for (Bullet b : bullets) {
            if (!inView(b.x,b.y,12)) continue;
            p.setColor(b.color); p.setAlpha(120); cv.drawCircle(b.x,b.y,b.r+4,p); p.setAlpha(255);
            p.setColor(b.color); cv.drawCircle(b.x,b.y,b.r,p);
            p.setColor(0xFFFFFFFF); cv.drawCircle(b.x,b.y,b.r*.35f,p);
        }

        // Player swords
        if (inView(player.x, player.y, 50)) {
            for (int si=0;si<2;si++) {
                Sword sw = si==0 ? player.sw1 : player.sw2;
                float ang = sw.spinning ? sw.currentAngle : sw.restAngle + player.facing;
                float orbitR=65;
                float sx=player.x+(float)Math.cos(ang)*orbitR;
                float sy=player.y+(float)Math.sin(ang)*orbitR;
                Renderer.drawSword(cv, sw.def, sx, sy, ang, sw.spinProgress, sw.spinning);
            }
            boolean flash = player.invincible>0 && (player.invincible/4)%2==1;
            Renderer.drawPlayer(cv, player.x, player.y, player.facing, flash);
        }

        cv.restore();

        // Screen overlays
        if (announceTimer > 0) {
            float alpha = Math.min(1f, announceTimer/60f);
            pt.setColor(0xFFFFFFFF); pt.setAlpha((int)(alpha*255));
            pt.setTextSize(dp(32)); pt.setTextAlign(Paint.Align.CENTER);
            pt.setShadowLayer(16,0,0, GameData.WORLDS[worldIdx].accentColor);
            cv.drawText("ВОЛНА  "+wave, W/2f, H/3f, pt);
            pt.clearShadowLayer(); pt.setAlpha(255);
        }
        if (state==State.WAVE_CLEAR) {
            pt.setColor(0xFFFFD700); pt.setTextSize(dp(26)); pt.setTextAlign(Paint.Align.CENTER);
            cv.drawText("✓  ВОЛНА "+wave+" ПРОЙДЕНА!", W/2f, H/2f, pt);
        }

        // Vignette
        RadialGradient rg = new RadialGradient(W/2f,H/2f,Math.max(W,H)*.75f, new int[]{0x00000000,0xCC000000}, new float[]{0.35f,1f}, Shader.TileMode.CLAMP);
        p.setShader(rg); cv.drawRect(0,0,W,H,p); p.setShader(null);
    }

    // ── Particle helpers ─────────────────────────────────────────────────
    void addParticle(float x,float y,float vx,float vy,int color,int life,float r) {
        if (particles.size()>320) return;
        Particle pt=new Particle(); pt.x=x;pt.y=y;pt.vx=vx;pt.vy=vy;pt.color=color;pt.life=pt.maxLife=life;pt.r=r; particles.add(pt);
    }
    void burst(float x,float y,int color,int n) { for(int i=0;i<n;i++){float a=rng.nextFloat()*(float)(Math.PI*2);addParticle(x,y,(float)Math.cos(a)*(2+rng.nextFloat()*5),(float)Math.sin(a)*(2+rng.nextFloat()*5),color,14+rng.nextInt(12),3+rng.nextFloat()*3);} }
    void burst2(float x,float y,int color,int n) { for(int i=0;i<n;i++){float a=i*(float)(Math.PI*2)/n;addParticle(x,y,(float)Math.cos(a)*(3+rng.nextFloat()*7),(float)Math.sin(a)*(3+rng.nextFloat()*7),color,30+rng.nextInt(20),5+rng.nextFloat()*4);} }
    void addNumber(float x,float y,int val,int color) {
        if (particles.size()>320) return;
        Particle pt=new Particle(); pt.isNum=true; pt.text=String.valueOf(val); pt.x=x+rng.nextFloat()*20-10; pt.y=y; pt.vx=(rng.nextFloat()-.5f); pt.vy=-2.5f; pt.color=color; pt.life=pt.maxLife=50; pt.r=1; particles.add(pt);
    }
    void lightningLine(float x1,float y1,float x2,float y2) { int segs=8; float sx=x1,sy=y1; for(int i=1;i<=segs;i++){float tx=x1+(x2-x1)*i/segs+rng.nextFloat()*30-15,ty=y1+(y2-y1)*i/segs+rng.nextFloat()*30-15;addParticle((sx+tx)/2,(sy+ty)/2,0,0,0xFFFFFF44,10,3);sx=tx;sy=ty;} }
    void shake(float amt) { shakeAmt=Math.max(shakeAmt,amt); }

    // ── Helpers ───────────────────────────────────────────────────────────
    float dist(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return(float)Math.sqrt(dx*dx+dy*dy);}
    float dist(float dx,float dy){return(float)Math.sqrt(dx*dx+dy*dy);}
    float dp(float d){return d*getResources().getDisplayMetrics().density;}
    boolean inView(float x,float y,float r){return x+r>camX&&x-r<camX+getWidth()&&y+r>camY&&y-r<camY+getHeight();}
    void notifyHud(){if(cb!=null)cb.onHud(player.hp,player.maxHp,(int)player.stamina,(int)player.maxStamina,wave,waveTotal,sessionScore,player.skillCd,player.dashCd);}

    // ── Loop ──────────────────────────────────────────────────────────────
    @Override public void run() {
        while (running) {
            long s=System.currentTimeMillis();
            update();
            SurfaceHolder h=getHolder();
            if (h.getSurface().isValid()) { Canvas c=h.lockCanvas(); if(c!=null){render(c);h.unlockCanvasAndPost(c);} }
            long sl=16-(System.currentTimeMillis()-s); if(sl>0) try{Thread.sleep(sl);}catch(Exception ignored){}
        }
    }
    @Override public void surfaceCreated(SurfaceHolder h){running=true;thread=new Thread(this);thread.start();notifyHud();}
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh){}
    @Override public void surfaceDestroyed(SurfaceHolder h){running=false;try{thread.join(500);}catch(Exception ignored){}}

    // ── Public API ────────────────────────────────────────────────────────
    public void setJoy(float x,float y){joyX=x;joyY=y;}
    public void tapAttack(){flagAttack=true;}
    public void tapSkill(){flagSkill=true;}
    public void tapDash(){flagDash=true;}
    public void pause(){state=State.PAUSED;}
    public void resume(){if(state==State.PAUSED)state=State.PLAYING;}
    public boolean isPaused(){return state==State.PAUSED;}
    public Player getPlayer(){return player;}
    public int getScore(){return sessionScore;}
    public int getGold(){return sessionGold;}
    public int getSkillCd(){return player.skillCd;}
    public int getDashCd(){return player.dashCd;}
    public Sword getSw1(){return player.sw1;}
    public Sword getSw2(){return player.sw2;}
}
