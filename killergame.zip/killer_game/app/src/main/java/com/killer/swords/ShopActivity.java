package com.killer.swords;

import android.app.Activity;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class ShopActivity extends Activity {

    TextView tvGold;
    int currentTab = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_shop);
        tvGold = findViewById(R.id.tvGold);
        refreshGold();
        buildTabs();
        showTab(0);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    @Override protected void onResume() { super.onResume(); refreshGold(); }

    void refreshGold() { if (tvGold!=null) tvGold.setText("💰 "+GameData.getGold(this)); }

    void buildTabs() {
        LinearLayout bar = findViewById(R.id.tabBar);
        bar.removeAllViews();
        String[] names = {"Мечи","Апгрейды","Расходники"};
        for (int i=0;i<names.length;i++) {
            final int idx=i;
            TextView tv=new TextView(this);
            tv.setText(names[i]);tv.setTextSize(13);tv.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
            tv.setTextColor(i==currentTab?0xFFFFD700:0xFF888888);
            tv.setGravity(android.view.Gravity.CENTER);tv.setPadding(dp(12),dp(10),dp(12),dp(10));
            tv.setBackgroundColor(i==currentTab?0x33FFD700:0);
            tv.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1));
            tv.setOnClickListener(v->{currentTab=idx;showTab(idx);buildTabs();});
            bar.addView(tv);
        }
    }

    void showTab(int tab) {
        LinearLayout content=findViewById(R.id.shopContent);
        content.removeAllViews();
        switch(tab){
            case 0: swordsTab(content); break;
            case 1: upgradesTab(content); break;
            case 2: consumablesTab(content); break;
        }
    }

    void swordsTab(LinearLayout root) {
        hint(root,"Нажми на меч чтобы выбрать слот экипировки");
        for (GameData.SwordDef sw : GameData.SWORDS) {
            boolean unlocked=GameData.isSwordUnlocked(this,sw.id);
            boolean eq1=GameData.getEquippedSword(this,1)==sw.id;
            boolean eq2=GameData.getEquippedSword(this,2)==sw.id;
            int lv=GameData.getSwordLevel(this,sw.id);

            LinearLayout card=makeCard(unlocked);

            // header
            LinearLayout hdr=new LinearLayout(this);hdr.setOrientation(LinearLayout.HORIZONTAL);hdr.setGravity(android.view.Gravity.CENTER_VERTICAL);
            View dot=new View(this);dot.setLayoutParams(new LinearLayout.LayoutParams(dp(12),dp(12)));dot.setBackgroundColor(unlocked?sw.color:0xFF333333);hdr.addView(dot);
            TextView tn=new TextView(this);tn.setText("  "+sw.name);tn.setTextSize(16);tn.setTextColor(unlocked?sw.color:0xFF555555);tn.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);tn.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));hdr.addView(tn);
            if(eq1) addBadge(hdr,"СЛ1",0xFF4444FF);
            if(eq2) addBadge(hdr,"СЛ2",0xFF44AA44);
            if(!unlocked) addBadge(hdr,"🔒 Ур."+sw.unlockLevel,0xFF555555); else addBadge(hdr,"Ур."+lv,0xFF666666);
            card.addView(hdr);

            // desc
            addInfo(card,sw.desc,0xFF666666,11);

            if (unlocked) {
                LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);row2.setPadding(0,dp(3),0,0);
                addInfoInline(row2,"Урон: "+(sw.baseDmg*lv)+" ",sw.color);
                addInfoInline(row2,"Рывок: "+sw.dashType.name+"  ",0xFFAAAAAA);
                addInfoInline(row2,sw.skillType.name,0xFF88AAFF);
                card.addView(row2);

                LinearLayout btnRow=new LinearLayout(this);btnRow.setOrientation(LinearLayout.HORIZONTAL);btnRow.setPadding(0,dp(8),0,0);
                Button b1=smallBtn("⚔ Слот 1",eq1?0xFF2222AA:0xFF222233,()->{GameData.equipSword(this,1,sw.id);showTab(0);buildTabs();});
                Button b2=smallBtn("⚔ Слот 2",eq2?0xFF226622:0xFF223322,()->{GameData.equipSword(this,2,sw.id);showTab(0);buildTabs();});
                LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);blp.setMargins(0,0,dp(6),0);b1.setLayoutParams(blp);b2.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
                btnRow.addView(b1);btnRow.addView(b2);card.addView(btnRow);
            }
            root.addView(card);
        }
    }

    void upgradesTab(LinearLayout root) {
        for (GameData.SwordDef sw : GameData.SWORDS) {
            if (!GameData.isSwordUnlocked(this,sw.id)) continue;
            int lv=GameData.getSwordLevel(this,sw.id);
            int price=60*lv;
            shopItem(root,"⬆ "+sw.name+" → Ур."+(lv+1),"Урон: "+(sw.baseDmg*lv)+" → "+(sw.baseDmg*(lv+1)),price,sw.color,()->{
                if(GameData.getGold(this)<price){toast("Мало золота!");return;}
                GameData.setSwordLevel(this,sw.id,lv+1);GameData.spendGold(this,price);showTab(1);refreshGold();
            });
        }
        int curHp=GameData.getPlayerMaxHp(this);
        shopItem(root,"❤ +50 Макс. HP","HP: "+curHp+" → "+(curHp+50),80,0xFFFF2244,()->{
            if(GameData.getGold(this)<80){toast("Мало золота!");return;}
            GameData.setPlayerMaxHp(this,curHp+50);GameData.spendGold(this,80);showTab(1);refreshGold();
        });
        float curSpd=GameData.getPlayerSpeed(this);
        shopItem(root,"💨 Скорость +0.5","Скорость: "+curSpd+" → "+(curSpd+.5f),70,0xFF44FFAA,()->{
            if(GameData.getGold(this)<70){toast("Мало золота!");return;}
            GameData.setPlayerSpeed(this,curSpd+.5f);GameData.spendGold(this,70);showTab(1);refreshGold();
        });
    }

    void consumablesTab(LinearLayout root) {
        shopItem(root,"💊 Аптечка","Восстановить 50 HP в следующем уровне",30,0xFFFF4466,()->{if(GameData.getGold(this)<30){toast("Мало!");return;}GameData.spendGold(this,30);toast("Куплено!");refreshGold();});
        shopItem(root,"⚡ Ускорение","Скорость атаки +30% на уровень",50,0xFFFFFF44,()->{if(GameData.getGold(this)<50){toast("Мало!");return;}GameData.spendGold(this,50);toast("Куплено!");refreshGold();});
        shopItem(root,"🛡 Броня","Урон -25% на один уровень",60,0xFF4488FF,()->{if(GameData.getGold(this)<60){toast("Мало!");return;}GameData.spendGold(this,60);toast("Куплено!");refreshGold();});
        shopItem(root,"💣 Граната","Взрыв — уничтожает всех на экране",120,0xFFFF8800,()->{if(GameData.getGold(this)<120){toast("Мало!");return;}GameData.spendGold(this,120);toast("Куплено!");refreshGold();});
    }

    // ── UI helpers ────────────────────────────────────────────────────────
    LinearLayout makeCard(boolean active) {
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackgroundColor(active?0xFF181818:0xFF0E0E0E);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0,0,0,dp(8));card.setLayoutParams(lp);
        return card;
    }

    void shopItem(LinearLayout parent, String name, String desc, int price, int color, Runnable action) {
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));
        card.setBackgroundColor(0xFF181818);card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);clp.setMargins(0,0,0,dp(8));card.setLayoutParams(clp);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
        addInfo(info,name,color,14);addInfo(info,desc,0xFF666666,11);card.addView(info);
        Button btn=new Button(this);btn.setText("💰 "+price);btn.setTextColor(GameData.getGold(this)>=price?0xFFFFD700:0xFF555555);
        btn.setTextSize(12);btn.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);btn.setBackgroundColor(0xFF2A2A1A);btn.setPadding(dp(10),dp(6),dp(10),dp(6));btn.setStateListAnimator(null);
        btn.setOnClickListener(v->{ if(GameData.getGold(this)<price){toast("Мало золота!");return;} action.run(); });
        card.addView(btn);parent.addView(card);
    }

    void hint(LinearLayout p2, String text) { addInfo(p2,text,0xFF555555,11); }

    void addInfo(LinearLayout p2, String text, int color, int size) {
        TextView tv=new TextView(this);tv.setText(text);tv.setTextSize(size);tv.setTextColor(color);tv.setTypeface(Typeface.MONOSPACE);p2.addView(tv);
    }

    void addInfoInline(LinearLayout p2, String text, int color) {
        TextView tv=new TextView(this);tv.setText(text);tv.setTextSize(10);tv.setTextColor(color);tv.setTypeface(Typeface.MONOSPACE);p2.addView(tv);
    }

    void addBadge(LinearLayout p2, String text, int color) {
        TextView t=new TextView(this);t.setText(text);t.setTextSize(9);t.setTextColor(color);t.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);t.setPadding(dp(4),dp(2),dp(4),dp(2));t.setBackgroundColor(color&0x00FFFFFF|0x22000000);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(dp(4),0,0,0);t.setLayoutParams(lp);p2.addView(t);
    }

    Button smallBtn(String text, int bg, Runnable action) {
        Button b=new Button(this);b.setText(text);b.setTextColor(0xFFFFFFFF);b.setTextSize(11);b.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);b.setBackgroundColor(bg);b.setPadding(dp(6),dp(6),dp(6),dp(6));b.setStateListAnimator(null);b.setOnClickListener(v->action.run());return b;
    }

    void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();}
    int dp(float d){return(int)(d*getResources().getDisplayMetrics().density);}
}
