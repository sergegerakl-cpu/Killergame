package com.killer.swords;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
public class LobbyActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_lobby);
        refresh();
        findViewById(R.id.btnPlay).setOnClickListener(v->startActivity(new Intent(this,LevelSelectActivity.class)));
        findViewById(R.id.btnShop).setOnClickListener(v->startActivity(new Intent(this,ShopActivity.class)));
        findViewById(R.id.btnSettings).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        findViewById(R.id.btnExit).setOnClickListener(v->finish());
    }
    @Override protected void onResume(){super.onResume();refresh();}
    void refresh(){
        TextView tvG=findViewById(R.id.tvGold);if(tvG!=null)tvG.setText("💰 "+GameData.getGold(this));
        TextView tvS=findViewById(R.id.tvScore);if(tvS!=null)tvS.setText("РЕКОРД: "+GameData.getTotalScore(this));
        TextView tvSw=findViewById(R.id.tvSword);if(tvSw!=null){GameData.SwordDef s1=GameData.getSword(GameData.getEquippedSword(this,1)),s2=GameData.getSword(GameData.getEquippedSword(this,2));tvSw.setText("⚔ "+s1.name+" + "+s2.name);}
        int max=GameData.getMaxUnlockedLevel(this),total=25;
        TextView tvP=findViewById(R.id.tvProgress);if(tvP!=null)tvP.setText("Прогресс: "+max+" / "+total+" уровней");
        View pf=findViewById(R.id.progressFill),pb=findViewById(R.id.progressBar);
        if(pf!=null&&pb!=null)pb.post(()->{ViewGroup.LayoutParams lp=pf.getLayoutParams();lp.width=(int)(pb.getWidth()*(float)max/total);pf.setLayoutParams(lp);});
    }
}
