package com.killer.swords;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        int hs = getSharedPreferences("ks", MODE_PRIVATE).getInt("hs", 0);
        TextView tv = findViewById(R.id.tvHs);
        if (tv != null && hs > 0) tv.setText("РЕКОРД: " + hs);
        findViewById(R.id.btnPlay).setOnClickListener(v ->
                startActivity(new Intent(this, GameActivity.class)));
        findViewById(R.id.btnExit).setOnClickListener(v -> finish());
    }
}
