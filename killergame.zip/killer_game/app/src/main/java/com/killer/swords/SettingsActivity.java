package com.killer.swords;
import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_settings);
        Switch ss=findViewById(R.id.swSound),sv=findViewById(R.id.swVib);
        if(ss!=null){ss.setChecked(GameData.isSoundOn(this));ss.setOnCheckedChangeListener((v,c)->GameData.setSound(this,c));}
        if(sv!=null){sv.setChecked(GameData.isVibrationOn(this));sv.setOnCheckedChangeListener((v,c)->GameData.setVibration(this,c));}
        RadioGroup rg=findViewById(R.id.rgGfx);
        if(rg!=null){int gfx=GameData.getGraphicsQuality(this);rg.check(gfx==0?R.id.rbLow:gfx==1?R.id.rbMed:R.id.rbHigh);rg.setOnCheckedChangeListener((g,id)->{if(id==R.id.rbLow)GameData.setGraphicsQuality(this,0);else if(id==R.id.rbMed)GameData.setGraphicsQuality(this,1);else GameData.setGraphicsQuality(this,2);});}
        TextView tv=findViewById(R.id.tvVer);if(tv!=null)tv.setText("Версия 1.0  •  Киллер: Мечи Судьбы");
        Button br=findViewById(R.id.btnReset);if(br!=null)br.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Сбросить прогресс?").setMessage("Весь прогресс будет удалён.").setPositiveButton("Сбросить",(d,w)->getSharedPreferences("ks_save",MODE_PRIVATE).edit().clear().apply()).setNegativeButton("Отмена",null).show());
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
    }
}
