package com.killer.swords;
import android.graphics.*;
public class Renderer {
    private static final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint ps=new Paint(Paint.ANTI_ALIAS_FLAG);
    static{ps.setStyle(Paint.Style.STROKE);}
    public enum EnemyKind{GUARD,SNIPER,HEAVY,DRONE,DOG,MAGE,ROBOT,BOSS_MAIN,BOSS_FINAL}

    public static void drawPlayer(Canvas cv,float x,float y,float facing,boolean flash){
        if(flash)return;
        p.setColor(0x44000000);cv.drawOval(x-18,y+14,x+18,y+20,p);
        p.setColor(0xFF1A1E30);cv.drawCircle(x,y,20,p);
        ps.setColor(0xFF4466AA);ps.setStrokeWidth(3.5f);cv.drawCircle(x,y,18,ps);
        ps.setColor(0xFF223355);ps.setStrokeWidth(2);cv.drawCircle(x,y,13,ps);
        p.setColor(0xFF2244CC);cv.drawCircle(x,y,8,p);
        p.setColor(0xFF4488FF);cv.drawCircle(x,y,4,p);
        p.setColor(0xAABBDDFF);cv.drawCircle(x,y,2,p);
        float lx=x-(float)Math.cos(facing+Math.PI/2)*14,ly=y-(float)Math.sin(facing+Math.PI/2)*14;
        float rx2=x+(float)Math.cos(facing+Math.PI/2)*14,ry2=y+(float)Math.sin(facing+Math.PI/2)*14;
        p.setColor(0xFF2A3A5A);cv.drawCircle(lx,ly,7,p);cv.drawCircle(rx2,ry2,7,p);
        ps.setColor(0xFF5577AA);ps.setStrokeWidth(1.5f);cv.drawCircle(lx,ly,7,ps);cv.drawCircle(rx2,ry2,7,ps);
        float hx=x+(float)Math.cos(facing)*10,hy=y+(float)Math.sin(facing)*10;
        p.setColor(0xFF334466);cv.drawCircle(hx,hy,7,p);
        p.setColor(0xFF00CCFF);cv.drawCircle(hx,hy,4,p);
        p.setColor(0xFFAAEEFF);cv.drawCircle(hx+(float)Math.cos(facing)*1.5f,hy+(float)Math.sin(facing)*1.5f,2,p);
        float t=System.currentTimeMillis()/120f;
        ps.setColor(0xFF223355);ps.setStrokeWidth(5);
        float ppx=(float)Math.cos(facing+Math.PI/2),ppy=(float)Math.sin(facing+Math.PI/2);
        float l1x=x+ppx*8+(float)Math.cos(facing)*(float)Math.sin(t)*6,l1y=y+ppy*8+(float)Math.sin(facing)*(float)Math.sin(t)*6+16;
        float l2x=x-ppx*8+(float)Math.cos(facing)*(float)Math.sin(t+(float)Math.PI)*6,l2y=y-ppy*8+(float)Math.sin(facing)*(float)Math.sin(t+(float)Math.PI)*6+16;
        cv.drawLine(x+ppx*8,y+ppy*8+5,l1x,l1y,ps);cv.drawLine(x-ppx*8,y-ppy*8+5,l2x,l2y,ps);
        p.setColor(0xFF334455);cv.drawCircle(l1x,l1y,5,p);cv.drawCircle(l2x,l2y,5,p);
    }

    public static void drawSword(Canvas cv,GameData.SwordDef def,float cx,float cy,float angle,float sp,boolean spin){
        cv.save();cv.translate(cx,cy);cv.rotate((float)Math.toDegrees(angle)+45);
        int c=def.color;
        p.setColor(c&0x00FFFFFF|(spin?0x66000000:0x33000000));cv.drawRoundRect(-10,-34,10,18,5,5,p);
        p.setColor(c);cv.drawRoundRect(-4,-32,4,2,2,2,p);
        p.setColor(blend(c,0xFFFFFFFF,0.4f));cv.drawRoundRect(-1.5f,-32,1.5f,0,1,1,p);
        switch(def.id){
            case FIRE:{float fl=(float)(Math.sin(System.currentTimeMillis()/80.0)*2);p.setColor(0x44FF4400);cv.drawRoundRect(-10,-36+fl,10,14,5,5,p);p.setColor(0xFFFF2200);cv.drawCircle(-1.5f,-20,2.5f,p);cv.drawCircle(1f,-12,2f,p);break;}
            case ICE:{p.setColor(0xFFAADDFF);cv.drawRect(-3,-28,-1,-22,p);cv.drawRect(1,-18,3,-10,p);ps.setColor(0xFFAADDFF);ps.setStrokeWidth(2);cv.drawLine(-10,0,10,0,ps);cv.drawLine(0,-3,0,4,ps);break;}
            case LIGHTNING:{if(spin||System.currentTimeMillis()%200<100){ps.setColor(0x88FFFF44);ps.setStrokeWidth(1.5f);cv.drawLine(-5,-30,3,-22,ps);cv.drawLine(3,-22,-4,-14,ps);}ps.setColor(0xFFFFFF00);ps.setStrokeWidth(1.5f);cv.drawLine(-2,-26,2,-20,ps);cv.drawLine(2,-20,-2,-14,ps);p.setColor(0xAAFFFF44);cv.drawCircle(0,-34,5,p);break;}
            case VORTEX:{ps.setColor(0x66AA44FF);ps.setStrokeWidth(2);cv.drawCircle(0,-14,18,ps);cv.save();cv.rotate(sp*360);ps.setColor(0x44884FCC);cv.drawOval(-8,-28,8,0,ps);cv.restore();break;}
            case SHADOW:{p.setColor(0x33CC00AA);cv.drawRoundRect(-8,-36,8,16,4,4,p);p.setColor(0xFF440033);cv.drawCircle(0,-34,5,p);p.setColor(0xFFFF00CC);cv.drawCircle(0,-34,2,p);break;}
            case PLASMA:{float pulse=(float)(Math.sin(System.currentTimeMillis()/100.0)*2);p.setColor(0x5500FFCC);cv.drawRoundRect(-10,-36+pulse,10,16+pulse,5,5,p);p.setColor(c);cv.drawCircle(-2,-26,3,p);cv.drawCircle(2,-16,3,p);cv.drawCircle(-2,-6,3,p);p.setColor(0xFFFFFFFF);cv.drawCircle(0,-34,2,p);break;}
            case TSUNAMI:{float wave=(float)(Math.sin(System.currentTimeMillis()/120.0)*3);ps.setColor(0xFF0066FF);ps.setStrokeWidth(1.5f);for(int i=0;i<3;i++)cv.drawLine(-3.5f,-28+i*8+wave,3.5f,-28+i*8+wave+2,ps);p.setColor(0xFFCCDDFF);cv.drawCircle(0,-34,4,p);break;}
            case EARTHQUAKE:{ps.setColor(0xFF5C3317);ps.setStrokeWidth(1.5f);cv.drawLine(-3,-28,1,-22,ps);cv.drawLine(1,-22,-2,-16,ps);p.setColor(0xFF6B4226);cv.drawCircle(-2,-20,2,p);cv.drawCircle(2,-10,1.5f,p);p.setColor(c);cv.drawCircle(0,-34,5,p);p.setColor(0xFFDEB887);cv.drawCircle(0,-34,2,p);break;}
        }
        p.setColor(0xFF888888);cv.drawRoundRect(-12,-3,12,4,3,3,p);
        p.setColor(blend(c,0xFF000000,0.5f));cv.drawRoundRect(-3.5f,4,3.5f,16,2,2,p);
        ps.setColor(blend(c,0xFF888888,0.5f));ps.setStrokeWidth(1.5f);
        for(int i=1;i<=4;i++)cv.drawLine(-3.5f,4+i*2.5f,3.5f,4+i*2.5f,ps);
        p.setColor(0xFF999999);cv.drawCircle(0,19,5,p);
        cv.restore();
    }

    public static void drawEnemy(Canvas cv,EnemyKind kind,float x,float y,float r,float facing,float hpFrac,boolean isBoss,int burn,int frozen,float phase){
        cv.save();cv.translate(x,y);
        if(frozen>0){p.setColor(0x5588DDFF);cv.drawCircle(0,0,r+6,p);}
        if(burn>0&&(burn/5)%2==0){p.setColor(0x55FF4400);cv.drawCircle(0,0,r+7,p);}
        int bc=isBoss?0xFFFF0044:0xFFCC3333;
        switch(kind){
            case GUARD:bc=0xFFCC3333;break;case SNIPER:bc=0xFF778833;break;case HEAVY:bc=0xFF2244AA;break;
            case DRONE:bc=0xFF445566;break;case DOG:bc=0xFF885533;break;case MAGE:bc=0xFF660088;break;
            case ROBOT:bc=0xFF334455;break;case BOSS_MAIN:bc=0xFFCC0033;break;case BOSS_FINAL:bc=0xFF880099;break;
        }
        p.setColor(0x33000000);cv.drawOval(-r*.8f,r*.5f,r*.8f,r,p);
        p.setColor(bc);cv.drawCircle(0,0,r,p);
        ps.setColor(blend(bc,0xFFFFFFFF,0.25f));ps.setStrokeWidth(2.5f);cv.drawCircle(0,0,r-1.5f,ps);
        p.setColor(blend(bc,0xFF000000,0.5f));cv.drawCircle(0,0,r*.45f,p);
        float ea=(float)Math.atan2(0-y,0-x);
        float ex2=(float)Math.cos(facing)*r*.4f,ey2=(float)Math.sin(facing)*r*.4f;
        p.setColor(0xFFFFFFFF);cv.drawCircle(ex2,ey2,isBoss?7:5,p);
        p.setColor(isBoss?0xFFFF00CC:0xFFFF0000);cv.drawCircle(ex2,ey2,isBoss?4:3,p);
        if(isBoss&&kind==EnemyKind.BOSS_MAIN){
            p.setColor(0xFFFFD700);
            for(int i=0;i<6;i++){float a=i*(float)(Math.PI/3)+phase;cv.drawRoundRect((float)Math.cos(a)*r-3,(float)Math.sin(a)*r-10,(float)Math.cos(a)*r+3,(float)Math.sin(a)*r+2,1,1,p);}
        }
        if(isBoss&&kind==EnemyKind.BOSS_FINAL){
            p.setColor(0x88440055);
            Path lw=new Path();lw.moveTo(-r*.5f,-r*.3f);lw.lineTo(-r*2.2f,-r*.1f);lw.lineTo(-r*1.8f,r*.4f);lw.lineTo(-r*.5f,r*.3f);lw.close();
            Path rw=new Path();rw.moveTo(r*.5f,-r*.3f);rw.lineTo(r*2.2f,-r*.1f);rw.lineTo(r*1.8f,r*.4f);rw.lineTo(r*.5f,r*.3f);rw.close();
            cv.drawPath(lw,p);cv.drawPath(rw,p);
            p.setColor(0xFFCC00FF);cv.drawCircle(ex2-8,ey2-r*.4f,6,p);cv.drawCircle(ex2+8,ey2-r*.4f,6,p);
            p.setColor(0xFF330044);cv.drawRoundRect(-r*.4f,-r*1.1f,-r*.2f,-r*.7f,2,2,p);cv.drawRoundRect(r*.2f,-r*1.1f,r*.4f,-r*.7f,2,2,p);
        }
        if(kind==EnemyKind.GUARD||kind==EnemyKind.HEAVY||kind==EnemyKind.ROBOT){
            ps.setColor(blend(bc,0xFF000000,0.3f));ps.setStrokeWidth(4);
            cv.drawLine(-6,r*.5f,-6+(float)Math.sin(phase)*5,r+4,ps);
            cv.drawLine(6,r*.5f,6+(float)Math.sin(phase+(float)Math.PI)*5,r+4,ps);
        }
        if(kind==EnemyKind.SNIPER||kind==EnemyKind.MAGE||kind==EnemyKind.DRONE){
            ps.setColor(blend(bc,0xFFFFFFFF,0.5f));ps.setStrokeWidth(4);
            cv.drawLine(0,0,(float)Math.cos(facing)*r*1.8f,(float)Math.sin(facing)*r*1.8f,ps);
        }
        if(kind==EnemyKind.DOG){
            ps.setColor(bc);ps.setStrokeWidth(3);
            cv.drawLine(-r*1.0f,-r*.2f,-r*1.3f,-r*.7f+(float)Math.sin(phase*1.5f)*8,ps);
        }
        float bw=r*2.6f,bh=5,bx2=-bw/2,by2=-r-14;
        p.setColor(0xFF111111);cv.drawRoundRect(bx2,by2,bx2+bw,by2+bh,2,2,p);
        p.setColor(isBoss?0xFFFF00CC:(hpFrac>0.5f?0xFF22EE44:0xFFEE2222));
        cv.drawRoundRect(bx2,by2,bx2+bw*hpFrac,by2+bh,2,2,p);
        p.setColor(0x44FFFFFF);cv.drawRoundRect(bx2,by2,bx2+bw*hpFrac,by2+2,2,2,p);
        cv.restore();
    }

    public static void drawFloorTile(Canvas cv,int x,int y,int size,String theme,boolean alt){
        switch(theme){
            case"MANSION":p.setColor(alt?0xFF2A1A12:0xFF231610);cv.drawRect(x,y,x+size,y+size,p);ps.setColor(0xFF180C06);ps.setStrokeWidth(0.5f);for(int i=4;i<size;i+=8)cv.drawLine(x+i,y,x+i+(alt?2:-2),y+size,ps);break;
            case"OFFICE": p.setColor(alt?0xFF141822:0xFF0E1218);cv.drawRect(x,y,x+size,y+size,p);ps.setColor(0xFF0A0E14);ps.setStrokeWidth(1);cv.drawRect(x,y,x+size,y+size,ps);break;
            case"BASE":   p.setColor(alt?0xFF0E1610:0xFF0A100C);cv.drawRect(x,y,x+size,y+size,p);if(alt){ps.setColor(0xFF142214);ps.setStrokeWidth(1);cv.drawLine(x,y,x+size,y+size,ps);cv.drawLine(x+size,y,x,y+size,ps);}break;
            case"DUNGEON":p.setColor(alt?0xFF161008:0xFF0E0A04);cv.drawRect(x,y,x+size,y+size,p);ps.setColor(0xFF0A0804);ps.setStrokeWidth(2);cv.drawLine(x,y+size/2,x+size,y+size/2,ps);cv.drawLine(x+size/2,y,x+size/2,y+size/2,ps);break;
            case"TOWER":  p.setColor(alt?0xFF100814:0xFF0C0610);cv.drawRect(x,y,x+size,y+size,p);ps.setColor(0xFF0E0612);ps.setStrokeWidth(1);cv.drawRect(x,y,x+size,y+size,ps);break;
            default:      p.setColor(alt?0xFF1A1A1A:0xFF141414);cv.drawRect(x,y,x+size,y+size,p);
        }
    }
    public static void drawWallTile(Canvas cv,int x,int y,int s,String theme){
        int wc,bc2,sc;
        switch(theme){
            case"MANSION":wc=0xFF3A2418;bc2=0xFF4A3020;sc=0xFF2A1A10;break;
            case"OFFICE": wc=0xFF1E2842;bc2=0xFF2A3852;sc=0xFF151C30;break;
            case"BASE":   wc=0xFF1A2A1E;bc2=0xFF243830;sc=0xFF0E1A12;break;
            case"DUNGEON":wc=0xFF2A200E;bc2=0xFF3A2C12;sc=0xFF1A1408;break;
            case"TOWER":  wc=0xFF1E0E2E;bc2=0xFF2A1440;sc=0xFF14081E;break;
            default:      wc=0xFF2A1E1E;bc2=0xFF4A3838;sc=0xFF120E0E;
        }
        p.setColor(wc);cv.drawRect(x,y,x+s,y+s,p);
        p.setColor(bc2);cv.drawRect(x,y,x+s,y+7,p);
        p.setColor(sc);cv.drawRect(x+s-4,y,x+s,y+s,p);cv.drawRect(x,y+s-4,x+s,y+s,p);
        if(theme.equals("TOWER")){ps.setColor(0xFF440066);ps.setStrokeWidth(1);cv.drawRect(x+1,y+1,x+s-1,y+s-1,ps);}
    }

    static int blend(int c1,int c2,float t){
        int r1=(c1>>16)&0xFF,g1=(c1>>8)&0xFF,b1=c1&0xFF;
        int r2=(c2>>16)&0xFF,g2=(c2>>8)&0xFF,b2=c2&0xFF;
        return 0xFF000000|((int)(r1+(r2-r1)*t))<<16|((int)(g1+(g2-g1)*t))<<8|((int)(b1+(b2-b1)*t));
    }
}
