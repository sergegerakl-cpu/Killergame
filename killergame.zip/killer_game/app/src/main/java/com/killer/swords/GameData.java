package com.killer.swords;
import android.content.Context;
import android.content.SharedPreferences;

public class GameData {
    public enum SwordId { BASIC, FIRE, ICE, LIGHTNING, VORTEX, SHADOW, PLASMA, TSUNAMI, EARTHQUAKE }
    public static class SwordDef {
        public final SwordId id; public final String name, desc;
        public final int baseDmg, color, unlockLevel;
        public final DashType dashType; public final SkillType skillType;
        public SwordDef(SwordId id,String name,String desc,int dmg,int color,int unlock,DashType dash,SkillType skill){
            this.id=id;this.name=name;this.desc=desc;this.baseDmg=dmg;this.color=color;this.unlockLevel=unlock;this.dashType=dash;this.skillType=skill;}
    }
    public enum DashType {
        ROLL("Перекат","Быстрый уклон"),BLINK("Мигание","Телепорт"),
        SHADOW_STEP("Тень","Невидимость 0.5с"),FLAME_DASH("Огневой","Огненный след"),
        FROST_SLIDE("Ледяной","Заморозка на ходу"),THUNDER_LEAP("Молния","Гром в точке прибытия");
        public final String name,desc; DashType(String n,String d){name=n;desc=d;}
    }
    public enum SkillType {
        SPIN_360("Вращение","360° — всех рядом"),FIRE_STORM("Огненный вихрь","Смерч на 3с"),
        BLIZZARD("Буран","Заморозка всех"),THUNDER_STRIKE("Гром","Цепная молния x3"),
        BLACK_HOLE("Чёрная дыра","Притянуть всех"),SHADOW_REALM("Теневая зона","Урон + замедление"),
        PLASMA_BURST("Плазма","Взрыв во все стороны"),TIDAL_WAVE("Цунами","Волна сносит врагов"),
        QUAKE("Землетрясение","Оглушить всех 3с");
        public final String name,desc; SkillType(String n,String d){name=n;desc=d;}
    }
    public static final SwordDef[] SWORDS = {
        new SwordDef(SwordId.BASIC,"Клинки","Стальные двойные мечи",10,0xFFCCCCCC,0,DashType.ROLL,SkillType.SPIN_360),
        new SwordDef(SwordId.FIRE,"Огонь","Поджигают и жгут",16,0xFFFF6600,2,DashType.FLAME_DASH,SkillType.FIRE_STORM),
        new SwordDef(SwordId.ICE,"Лёд","Замораживают при ударе",13,0xFF66DDFF,4,DashType.FROST_SLIDE,SkillType.BLIZZARD),
        new SwordDef(SwordId.LIGHTNING,"Молния","Цепной разряд",20,0xFFFFFF44,6,DashType.THUNDER_LEAP,SkillType.THUNDER_STRIKE),
        new SwordDef(SwordId.VORTEX,"Вихрь","Притягивают и рвут",18,0xFFAA44FF,9,DashType.BLINK,SkillType.BLACK_HOLE),
        new SwordDef(SwordId.SHADOW,"Тень","Крит из тени",25,0xFFCC00AA,12,DashType.SHADOW_STEP,SkillType.SHADOW_REALM),
        new SwordDef(SwordId.PLASMA,"Плазма","Сжигает броню",30,0xFF00FFCC,16,DashType.BLINK,SkillType.PLASMA_BURST),
        new SwordDef(SwordId.TSUNAMI,"Цунами","Волновые атаки",28,0xFF0066FF,20,DashType.FROST_SLIDE,SkillType.TIDAL_WAVE),
        new SwordDef(SwordId.EARTHQUAKE,"Земля","Дрожь земли AOE",35,0xFFAA6600,25,DashType.ROLL,SkillType.QUAKE),
    };
    public static SwordDef getSword(SwordId id){ for(SwordDef s:SWORDS) if(s.id==id) return s; return SWORDS[0]; }

    public static class WorldDef {
        public final String name,subtitle,theme;
        public final int accentColor,bgDark,levelCount,unlockAtLevel;
        public WorldDef(String n,String sub,String theme,int accent,int bgD,int lvls,int unlock){
            name=n;subtitle=sub;this.theme=theme;accentColor=accent;bgDark=bgD;levelCount=lvls;unlockAtLevel=unlock;}
    }
    public static class LevelDef {
        public final int worldIdx,levelIdx,waves,enemyMult;
        public final boolean hasBoss; public final SwordId showcaseSword;
        public final String name,hint;
        public LevelDef(int w,int l,String name,int waves,int mult,boolean boss,SwordId sw,String hint){
            worldIdx=w;levelIdx=l;this.name=name;this.waves=waves;enemyMult=mult;hasBoss=boss;showcaseSword=sw;this.hint=hint;}
        public int globalIndex(){ return worldIdx*5+levelIdx; }
    }
    public static final WorldDef[] WORLDS = {
        new WorldDef("Особняк","Логово мафии","MANSION",0xFFCC3300,0xFF110808,5,0),
        new WorldDef("Офис","Штаб-квартира","OFFICE",0xFF0055CC,0xFF08080A,5,5),
        new WorldDef("База","Секретная база","BASE",0xFF009944,0xFF060E08,5,10),
        new WorldDef("Подземелье","Тёмный комплекс","DUNGEON",0xFF884400,0xFF0D0803,5,15),
        new WorldDef("Небоскрёб","Вершина власти","TOWER",0xFF8800CC,0xFF0C0811,5,20),
    };
    public static final LevelDef[][] LEVELS = {
        {new LevelDef(0,0,"Прихожая",2,1,false,SwordId.BASIC,"Освой базовые атаки"),
         new LevelDef(0,1,"Гостиная",2,1,false,SwordId.BASIC,"Враги начнут стрелять"),
         new LevelDef(0,2,"Кухня",3,2,false,SwordId.FIRE,"🔥 Открывается огонь!"),
         new LevelDef(0,3,"Подвал",3,2,false,SwordId.FIRE,"Тяжёлые охранники"),
         new LevelDef(0,4,"Зал с боссом",3,2,true,SwordId.FIRE,"БОСС: Дон Карлеоне")},
        {new LevelDef(1,0,"Лобби офиса",3,2,false,SwordId.ICE,"❄️ Открывается лёд!"),
         new LevelDef(1,1,"Коридор",3,2,false,SwordId.ICE,"Снайперы на позициях"),
         new LevelDef(1,2,"Конференц-зал",4,2,false,SwordId.LIGHTNING,"⚡ Молния открывается!"),
         new LevelDef(1,3,"Серверная",4,3,false,SwordId.LIGHTNING,"Роботы и турели"),
         new LevelDef(1,4,"Кабинет CEO",4,3,true,SwordId.LIGHTNING,"БОСС: Исполнительный директор")},
        {new LevelDef(2,0,"КПП",4,3,false,SwordId.VORTEX,"🌀 Вихрь открывается!"),
         new LevelDef(2,1,"Ангар",4,3,false,SwordId.VORTEX,"Дроны и вертолёты"),
         new LevelDef(2,2,"Лаборатория",5,3,false,SwordId.SHADOW,"🌑 Тень открывается!"),
         new LevelDef(2,3,"Реактор",5,4,false,SwordId.SHADOW,"Смертельные ловушки"),
         new LevelDef(2,4,"Командный центр",5,4,true,SwordId.SHADOW,"БОСС: Генерал")},
        {new LevelDef(3,0,"Катакомбы",5,4,false,SwordId.PLASMA,"⚡ Плазма открывается!"),
         new LevelDef(3,1,"Камеры",5,4,false,SwordId.PLASMA,"Тюремщики и мутанты"),
         new LevelDef(3,2,"Тёмный зал",6,4,false,SwordId.TSUNAMI,"🌊 Цунами открывается!"),
         new LevelDef(3,3,"Алтарь",6,5,false,SwordId.TSUNAMI,"Культисты и демоны"),
         new LevelDef(3,4,"Логово тёмного",6,5,true,SwordId.TSUNAMI,"БОСС: Тёмный жрец")},
        {new LevelDef(4,0,"Техэтаж",6,5,false,SwordId.EARTHQUAKE,"🌍 Земля открывается!"),
         new LevelDef(4,1,"Офисный этаж",6,5,false,SwordId.EARTHQUAKE,"Элита охраны"),
         new LevelDef(4,2,"Смотровая",7,6,false,SwordId.EARTHQUAKE,"Снайперы и техника"),
         new LevelDef(4,3,"Пентхаус",7,6,false,SwordId.EARTHQUAKE,"Личная гвардия"),
         new LevelDef(4,4,"Вершина",7,7,true,SwordId.EARTHQUAKE,"ФИНАЛЬНЫЙ БОСС")},
    };

    private static SharedPreferences p(Context c){ return c.getSharedPreferences("ks_save",Context.MODE_PRIVATE); }
    public static int getGold(Context c){ return p(c).getInt("gold",150); }
    public static void addGold(Context c,int g){ p(c).edit().putInt("gold",getGold(c)+g).apply(); }
    public static void spendGold(Context c,int g){ p(c).edit().putInt("gold",Math.max(0,getGold(c)-g)).apply(); }
    public static int getMaxUnlockedLevel(Context c){ return p(c).getInt("max_level",0); }
    public static void unlockLevel(Context c,int idx){ if(idx>getMaxUnlockedLevel(c)) p(c).edit().putInt("max_level",idx).apply(); }
    public static int getLevelStars(Context c,int gIdx){ return p(c).getInt("stars_"+gIdx,0); }
    public static void saveLevelStars(Context c,int gIdx,int stars){ if(stars>getLevelStars(c,gIdx)) p(c).edit().putInt("stars_"+gIdx,stars).apply(); }
    public static boolean isSwordUnlocked(Context c,SwordId id){ if(id==SwordId.BASIC) return true; return p(c).getBoolean("sword_"+id.name(),false); }
    public static void unlockSword(Context c,SwordId id){ p(c).edit().putBoolean("sword_"+id.name(),true).apply(); }
    public static SwordId getEquippedSword(Context c,int slot){ try{ return SwordId.valueOf(p(c).getString("eq"+slot,SwordId.BASIC.name())); }catch(Exception e){ return SwordId.BASIC; } }
    public static void equipSword(Context c,int slot,SwordId id){ p(c).edit().putString("eq"+slot,id.name()).apply(); }
    public static int getSwordLevel(Context c,SwordId id){ return p(c).getInt("slv_"+id.name(),1); }
    public static void setSwordLevel(Context c,SwordId id,int lv){ p(c).edit().putInt("slv_"+id.name(),lv).apply(); }
    public static int getPlayerMaxHp(Context c){ return p(c).getInt("p_maxhp",100); }
    public static void setPlayerMaxHp(Context c,int v){ p(c).edit().putInt("p_maxhp",v).apply(); }
    public static float getPlayerSpeed(Context c){ return p(c).getFloat("p_spd",3.8f); }
    public static void setPlayerSpeed(Context c,float v){ p(c).edit().putFloat("p_spd",v).apply(); }
    public static int getTotalScore(Context c){ return p(c).getInt("total_score",0); }
    public static void addScore(Context c,int s){ p(c).edit().putInt("total_score",getTotalScore(c)+s).apply(); }
    public static boolean isSoundOn(Context c){ return p(c).getBoolean("sound",true); }
    public static void setSound(Context c,boolean v){ p(c).edit().putBoolean("sound",v).apply(); }
    public static boolean isVibrationOn(Context c){ return p(c).getBoolean("vib",true); }
    public static void setVibration(Context c,boolean v){ p(c).edit().putBoolean("vib",v).apply(); }
    public static int getGraphicsQuality(Context c){ return p(c).getInt("gfx",1); }
    public static void setGraphicsQuality(Context c,int v){ p(c).edit().putInt("gfx",v).apply(); }
    public static int calcStars(int hp,int maxHp,int time,int maxTime){
        if(hp<=0) return 0;
        float hf=(float)hp/maxHp, tf=(float)time/maxTime;
        if(hf>0.7f&&tf<0.6f) return 3;
        if(hf>0.3f) return 2;
        return 1;
    }
}
