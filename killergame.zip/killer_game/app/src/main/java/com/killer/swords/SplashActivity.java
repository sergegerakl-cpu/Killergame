package com.killer.swords;
import android.app.Activity;
import android.content.Intent;
import android.os.*;
public class SplashActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        new Handler(Looper.getMainLooper()).postDelayed(()->{startActivity(new Intent(this,LobbyActivity.class));finish();},2000);
    }
}
